


-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`) VALUES
(1, 'Robert');

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `user_id`, `title`) VALUES
(1, 1, 'Video title -1'),
(2, 1, 'Video title -2'),
(3, 1, 'Video title -3');


<?php
namespace App\Services;

class Calculator {

    public function add($a, $b)
    {
        return $a + $b;
    }
}

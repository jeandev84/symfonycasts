<?php
namespace App\Services;

interface ServiceInterface {
    
}
